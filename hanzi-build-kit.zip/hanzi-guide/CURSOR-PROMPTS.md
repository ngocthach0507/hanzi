# 📋 BỘ LỆNH CURSOR AI — COPY-PASTE TỪNG CÁI

Đây là file tổng hợp tất cả lệnh cần paste vào Cursor AI Chat (Ctrl+L).
Thực hiện theo thứ tự từ trên xuống dưới.

---

## ═══════════════════════════════════
## NHÓM A: SETUP BAN ĐẦU
## ═══════════════════════════════════

### [A1] Khởi tạo dự án (chạy trong Terminal)
```
npx create-next-app@latest hanzi-io-vn --typescript --tailwind --app --no-src-dir --import-alias "@/*"
cd hanzi-io-vn
npm install @clerk/nextjs @supabase/supabase-js lucide-react clsx
```

---

### [A2] Tạo cấu trúc thư mục (paste vào Cursor Chat)
```
Tạo cấu trúc thư mục cho dự án Next.js học tiếng Trung hanzi.io.vn:

app/
  layout.tsx          - root layout với Clerk provider
  page.tsx            - trang chủ (landing page)
  (auth)/
    dang-nhap/page.tsx
    dang-ky/page.tsx
  (dashboard)/
    dashboard/page.tsx
  tu-vung/
    page.tsx           - tổng quan từ vựng
    hsk[level]/
      page.tsx         - danh sách bài của cấp độ
      [lesson]/
        page.tsx       - nội dung bài học
        chon-nghia/page.tsx
        chon-pinyin/page.tsx
        dien-tu/page.tsx
        luyen-nghe/page.tsx
        flashcard/page.tsx
        nhap-tu/page.tsx
  nang-cap/page.tsx
  api/
    payment/
      create/route.ts
      webhook/route.ts
    tts/[hanzi]/route.ts

components/
  Navbar.tsx
  Footer.tsx
  VocabCard.tsx
  FlashCard.tsx
  QuizChoice.tsx
  ProgressBar.tsx
  LessonSidebar.tsx
  UpgradeBanner.tsx
  LockOverlay.tsx

lib/
  supabase.ts
  types.ts
  srs.ts           - SM-2 algorithm

Tạo các file này với nội dung placeholder cơ bản.
```

---

### [A3] Tạo database Supabase (paste vào Cursor Chat)
```
Tạo file supabase/schema.sql với nội dung SQL đầy đủ để tạo database cho web học tiếng Trung:

-- Bảng từ vựng master
CREATE TABLE vocabulary (
  id SERIAL PRIMARY KEY,
  hanzi TEXT NOT NULL,
  pinyin TEXT NOT NULL,
  meaning_vi TEXT NOT NULL,
  part_of_speech TEXT,
  hsk_level INTEGER NOT NULL CHECK (hsk_level BETWEEN 1 AND 6),
  lesson_number INTEGER NOT NULL,
  order_in_lesson INTEGER DEFAULT 0,
  example_zh TEXT,
  example_pinyin TEXT,
  example_vi TEXT,
  image_url TEXT,
  audio_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Bảng bài học
CREATE TABLE lessons (
  id SERIAL PRIMARY KEY,
  hsk_level INTEGER NOT NULL,
  lesson_number INTEGER NOT NULL,
  title TEXT,
  word_count INTEGER DEFAULT 10,
  is_free BOOLEAN DEFAULT FALSE,
  UNIQUE(hsk_level, lesson_number)
);

-- Bảng tiến độ user (dùng Clerk user_id)
CREATE TABLE user_progress (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT NOT NULL,
  hsk_level INTEGER NOT NULL,
  lesson_number INTEGER NOT NULL,
  status TEXT DEFAULT 'not_started' CHECK (status IN ('not_started','learning','completed')),
  score INTEGER DEFAULT 0,
  completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, hsk_level, lesson_number)
);

-- Bảng SRS từ vựng
CREATE TABLE user_vocabulary (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT NOT NULL,
  vocab_id INTEGER REFERENCES vocabulary(id),
  ease_factor FLOAT DEFAULT 2.5,
  interval_days INTEGER DEFAULT 1,
  repetitions INTEGER DEFAULT 0,
  next_review DATE DEFAULT CURRENT_DATE,
  last_rating TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, vocab_id)
);

-- Bảng streak
CREATE TABLE user_streaks (
  user_id TEXT PRIMARY KEY,
  current_streak INTEGER DEFAULT 0,
  longest_streak INTEGER DEFAULT 0,
  last_active_date DATE,
  total_xp INTEGER DEFAULT 0
);

-- Bảng đăng ký trả phí
CREATE TABLE subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT NOT NULL UNIQUE,
  plan TEXT DEFAULT 'free' CHECK (plan IN ('free','pro','live')),
  started_at TIMESTAMPTZ DEFAULT NOW(),
  expires_at TIMESTAMPTZ,
  payment_ref TEXT,
  status TEXT DEFAULT 'active'
);

-- Seed bài học HSK 1: 50 bài, 3 bài đầu miễn phí
INSERT INTO lessons (hsk_level, lesson_number, title, word_count, is_free)
SELECT 
  1,
  g,
  'Bài ' || g,
  CASE WHEN g = 50 THEN 7 ELSE 10 END,
  CASE WHEN g <= 3 THEN TRUE ELSE FALSE END
FROM generate_series(1, 50) AS g;

-- Enable Row Level Security
ALTER TABLE user_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_vocabulary ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_streaks ENABLE ROW LEVEL SECURITY;

-- RLS policies (user chỉ thấy data của mình)
CREATE POLICY "user_own_progress" ON user_progress FOR ALL USING (user_id = current_setting('app.user_id', TRUE));
CREATE POLICY "user_own_vocab" ON user_vocabulary FOR ALL USING (user_id = current_setting('app.user_id', TRUE));
CREATE POLICY "user_own_streak" ON user_streaks FOR ALL USING (user_id = current_setting('app.user_id', TRUE));

-- Vocabulary và lessons là public read
ALTER TABLE vocabulary ENABLE ROW LEVEL SECURITY;
ALTER TABLE lessons ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public_read_vocab" ON vocabulary FOR SELECT USING (TRUE);
CREATE POLICY "public_read_lessons" ON lessons FOR SELECT USING (TRUE);
```

---

## ═══════════════════════════════════
## NHÓM B: COMPONENTS CHÍNH
## ═══════════════════════════════════

### [B1] Navbar component
```
Tạo file components/Navbar.tsx cho web hanzi.io.vn với Tailwind CSS.

Yêu cầu chính xác:
- 2 hàng navbar:
  HÀNG TRÊN: logo "hanzi.io.vn" (màu #D85A30, font-bold), ô tìm kiếm (rounded-full, placeholder "Tìm kiếm..."), nút Google Play (nền đen), App Store (nền đen), text "Liên hệ", nút "Đăng nhập" (border), nút "Đăng ký" (nền #2563EB, text trắng)
  
  HÀNG DƯỚI: menu items: Trang chủ 🏠, GT hán ngữ 📖, Luyện tập ▾ (dropdown), Từ vựng ▾ (dropdown), Hội thoại, Đọc hiểu, Bộ thủ, Luyện thi, Luyện thi mới, Dịch, nút "👑 Nâng cấp" (gradient vàng)

- Dropdown "Luyện tập": 5 items với icon tròn màu:
  🌐 Luyện dịch - Dịch câu Trung-Việt
  ↕ Sắp xếp câu - Sắp xếp từ thành câu đúng  
  ✗ Sửa câu sai - Tìm và sửa lỗi ngữ pháp
  Aa Điền từ - Điền từ còn thiếu vào câu
  💬 Hỏi đáp - Luyện phản xạ hội thoại Q&A

- Dropdown "Từ vựng": 4 items:
  🔥 Từ vựng HSK 3.0 - Bộ lesson mới chuẩn HSK 3.0
  📚 Từ vựng HSK - Học từ vựng theo bài và cấp độ
  🗂 Từ vựng chủ đề - Học từ vựng theo chủ đề giao tiếp
  ❝❞ Mẫu câu - Học mẫu câu tiếng Trung theo chủ đề

- Dropdown hiện khi hover, ẩn khi rời
- Mobile: hamburger menu, collapse menu
- Sticky top với backdrop-blur
- Dùng next/link cho tất cả href
- Tích hợp Clerk: UserButton khi đã đăng nhập, Đăng nhập/Đăng ký khi chưa
```

### [B2] Trang danh sách bài học
```
Tạo file app/tu-vung/hsk1/page.tsx - trang danh sách 50 bài HSK 1.

Layout:
- Breadcrumb: Trang chủ > Từ vựng HSK 3.0 > HSK 1
- Header: "Từ vựng HSK 1" + subtitle "Học theo bài ngắn, nhịp chia giống hệ HSK 3.0 mới"
- Stats: "50 Bài học · 497 Từ vựng"
- Filter tabs: Tất cả (50) | Đã xong (0) | Đang học (0) | Chưa mở (3)
- Grid 2 cột bài học, mỗi bài:
  - Số bài (bold lớn)
  - "Bài X" + "10 từ"  
  - Status badge: "Chưa học" / "Đang học" / "Đã xong" / "🔒 PRO"
  - Progress bar % 
  - Text nhỏ: "Sẵn sàng - Bắt đầu khi bạn muốn" hoặc "PRO"
  - Nút "Bắt đầu" (xanh) hoặc icon 🔒

Logic freemium: Bài 1-3 free, bài 4-50 cần PRO.
Nếu user free click bài 4+: hiện modal UpgradeBanner.

Lấy dữ liệu từ Supabase bảng lessons (hsk_level=1).
Lấy user_progress từ Supabase với clerk userId.
Dùng React Server Component + Suspense.
```

### [B3] Trang nội dung bài học
```
Tạo file app/tu-vung/hsk1/[lesson]/page.tsx

Layout chính xác giống HiHSK:
- Breadcrumb
- Header: "Bài X - 10 từ vựng · Đang học"
- Tabs ngang: [Từ vựng] [Chọn nghĩa] [Chọn phiên âm] [Chọn từ tiếng Trung] [Điền từ vào chỗ trống] [Luyện nghe] [Tổng hợp] [Flashcard] [Nhập từ vựng]
- Body 2 cột: danh sách từ (2/3) + sidebar danh sách bài (1/3)

Mỗi vocab card:
- STT | Ảnh (blur loading → clear) | Chữ Hán (text-4xl font-bold) | Pinyin (text-red-500) | Badge loại từ | Nghĩa tiếng Việt | Câu ví dụ (có màu từng chữ + pinyin nhỏ trên đầu) | Nút 🔊

Sidebar:
- Danh sách 1-50 bài
- Highlight bài hiện tại
- Bài lock hiện icon 🔒

Footer bài: nút "← Bài trước" và "Bài sau →"
Nút float bottom: "Luyện tập →" màu xanh

Data: Supabase vocabulary WHERE hsk_level=1 AND lesson_number=params.lesson
```

### [B4] Bài tập Chọn nghĩa (Quiz)
```
Tạo file app/tu-vung/hsk1/[lesson]/chon-nghia/page.tsx

Client component với state management.

UI:
- Header: "Chọn nghĩa · Bài X · HSK 1"
- Progress bar: X/10 + điểm hiện tại
- Câu hỏi: Hiển thị chữ Hán to (text-6xl) + pinyin
- 4 nút đáp án dạng grid 2x2, mỗi nút là nghĩa tiếng Việt
- Khi chọn đúng: nút chuyển xanh lá + icon ✓ + "+10 XP" popup animation + confetti nhỏ
- Khi chọn sai: nút chọn chuyển đỏ, nút đúng chuyển xanh + giải thích ngắn
- Delay 1.5s rồi chuyển câu tiếp
- Màn hình kết thúc: điểm số, % đúng, thời gian, "Làm lại" và "Bài tiếp theo →"

Logic:
- Lấy 10 từ của bài từ Supabase
- Shuffle thứ tự
- 4 đáp án: 1 đúng + 3 random từ cùng level (shuffle)
- Sau mỗi câu: gọi API cập nhật user_vocabulary SRS
- Cuối bài: gọi API cập nhật user_progress (status=completed nếu đúng ≥7/10)
```

### [B5] Flashcard với SRS
```
Tạo file app/tu-vung/hsk1/[lesson]/flashcard/page.tsx

Client component.

UI:
- Progress: X/10 thẻ, progress bar
- Thẻ lớn chính giữa (min-h-64):
  MẶT TRƯỚC: Chữ Hán cực lớn (text-8xl) + nút phát âm 🔊
  MẶT SAU (sau khi click/space): Pinyin đỏ + Nghĩa tiếng Việt lớn + Câu ví dụ + ảnh (nếu có)
  Animation flip 3D: CSS transform rotateY(180deg), transition 0.6s

- Hint: "Nhấn Space hoặc click thẻ để lật"
- Sau khi lật, hiện 3 nút:
  [😅 Khó] màu đỏ nhạt
  [🙂 Ổn] màu vàng nhạt  
  [😄 Dễ] màu xanh nhạt
- Keyboard shortcuts: 1=Khó, 2=Ổn, 3=Dễ

SRS (SM-2 algorithm trong lib/srs.ts):
function calculateSRS(easeFactor, interval, repetitions, rating: 'hard'|'ok'|'easy') {
  if (rating === 'hard') { repetitions=0; interval=1; easeFactor=max(1.3, ef-0.2) }
  else if (rating === 'ok') { interval = rep===0?1:rep===1?6:round(interval*ef); repetitions++; }
  else { interval = rep===0?1:rep===1?6:round(interval*ef)+1; repetitions++; easeFactor+=0.1 }
  return { easeFactor, interval, repetitions, nextReview: addDays(today, interval) }
}

Gọi PATCH /api/vocabulary/[id]/rate sau mỗi đánh giá.
```

### [B6] UpgradeBanner component (modal khóa nội dung)
```
Tạo file components/UpgradeBanner.tsx

2 dạng hiển thị:

DẠNG 1 - Modal overlay (khi click bài bị khóa):
- Overlay blur toàn màn hình
- Card trắng chính giữa với:
  Icon 👑 vàng lớn
  "Nâng cấp tài khoản" (text-2xl bold)
  "Bạn cần nâng cấp để truy cập bài học này"
  Danh sách: ∞ Truy cập không giới hạn tất cả bài học | 🤖 Luyện tập cùng AI tutor | 📈 Theo dõi tiến độ học tập chi tiết
  Nút "👑 Nâng cấp ngay" xanh lớn
  Text nhỏ: "Chỉ từ 99.000đ/tháng"
  Nút x đóng

DẠNG 2 - Banner inline (trong trang bài học):
- Nền gradient xanh dương
- Cùng nội dung nhưng dạng ngang
- Không có nút đóng

Props: isModal (boolean), onClose (function)
```

---

## ═══════════════════════════════════
## NHÓM C: TÍNH NĂNG NÂNG CAO
## ═══════════════════════════════════

### [C1] API Text-to-Speech
```
Tạo file app/api/tts/route.ts

Nhận POST với body { text: string, lang: 'zh-CN' }

Dùng Google Text-to-Speech API (hoặc nếu không có key thì dùng ResponsiveVoice CDN):

Option A - Google TTS:
  Gọi https://texttospeech.googleapis.com/v1/text:synthesize
  Voice: zh-CN-Standard-C, speed 0.85
  Return audio base64

Option B - Nếu không có Google API key:
  Return JSON { provider: 'browser', text, lang: 'zh-CN' }
  Client tự dùng window.speechSynthesis

Client component AudioButton.tsx:
  onClick: gọi API, nhận audio, play
  Fallback: window.speechSynthesis.speak()
  Button: 🔊 icon, loading spinner khi đang load
```

### [C2] Dashboard
```
Tạo file app/dashboard/page.tsx

Server component, yêu cầu đăng nhập (Clerk middleware).

Lấy data từ Supabase:
- user_streaks: streak hiện tại
- user_progress: số bài đã hoàn thành
- user_vocabulary: tổng từ đã học, từ cần ôn hôm nay (next_review <= today)

Layout:
- Greeting: "Chào [firstName]! " + icon 🔥 nếu streak > 0
- Row 1 stats: Streak X ngày 🔥 | X từ đã học | X bài hoàn thành | X% độ chính xác
- Streak calendar: 30 ô vuông nhỏ, màu xanh đậm/nhạt theo hoạt động
- "Bài học hôm nay": 3 card bài gợi ý (bài tiếp theo chưa làm)
- "Từ cần ôn hôm nay": list từ SRS due, nút "Ôn tập ngay →"
- Tiến độ HSK: 6 progress bar (HSK 1-6), % bài đã hoàn thành
- Bảng xếp hạng tuần: top 5 user, rank, avatar, tên, XP
```

### [C3] Trang thanh toán
```
Tạo file app/nang-cap/page.tsx

Layout:
- Hero: "Mở khóa toàn bộ hanzi.io.vn 🚀"
- Toggle Tháng/Năm (năm giảm 30%)
- 3 plan cards:
  
  MIỄN PHÍ:
  - 0₫/mãi mãi
  - 3 bài học miễn phí mỗi cấp
  - Flashcard cơ bản
  - Trắc nghiệm cơ bản
  ✗ Không: AI tutor, offline, live class
  
  PRO (highlight, border đỏ, badge "Phổ biến"):
  - 99,000₫/tháng hoặc 69,000₫/tháng (năm)
  - Toàn bộ 500+ bài học
  - 8 loại bài tập mỗi bài
  - Luyện phát âm AI
  - Theo dõi tiến độ SRS
  - App offline
  
  PRO + LIVE:
  - 199,000₫/tháng hoặc 139,000₫/tháng (năm)  
  - Tất cả Pro
  - Live class 2 buổi/tuần
  - Giáo viên bản ngữ
  - Nhóm học VIP

- Nút "Đăng ký ngay" → gọi API tạo PayOS link
- Testimonials ngắn 3 người
- FAQ 5 câu
- Guarantee: "Hoàn tiền 100% trong 30 ngày"

API route app/api/payment/create/route.ts:
POST { plan: 'pro'|'live', cycle: 'monthly'|'yearly' }
Tính amount, gọi PayOS createPaymentLink
Return { paymentUrl }
```

### [C4] Script import dữ liệu
```
Tạo file scripts/import-vocab.js (Node.js script, không phải Next.js)

Script đọc file data/hsk1-vocabulary.json và import vào Supabase:

const { createClient } = require('@supabase/supabase-js')
const data = require('../data/hsk1-vocabulary.json')

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_KEY)

async function main() {
  // Xóa data cũ (level 1)
  await supabase.from('vocabulary').delete().eq('hsk_level', 1)
  
  // Insert batch 50 records mỗi lần
  for (let i = 0; i < data.length; i += 50) {
    const batch = data.slice(i, i + 50)
    const { error } = await supabase.from('vocabulary').insert(batch)
    if (error) console.error('Error batch', i, error)
    else console.log('Imported batch', i, 'to', i + batch.length)
  }
  console.log('Done! Total:', data.length, 'records')
}

main()

Chạy: node scripts/import-vocab.js
```

---

## ═══════════════════════════════════
## NHÓM D: SỬA LỖI VÀ TỐI ƯU
## ═══════════════════════════════════

### [D1] Khi gặp lỗi TypeScript - paste lệnh này
```
File [tên file] đang báo lỗi TypeScript:
[paste nội dung lỗi]

Hãy sửa lỗi này. Không thay đổi logic chính, chỉ fix type errors.
```

### [D2] Khi trang không load data từ Supabase
```
Trang [tên trang] không hiển thị data từ Supabase.
Hãy kiểm tra và sửa:
1. Kết nối Supabase client (lib/supabase.ts)
2. Query đúng table và column names
3. RLS policies có cho phép read không
4. Console.log data để debug
```

### [D3] Responsive mobile
```
Kiểm tra và sửa responsive cho component [tên component].
Màn hình mobile (375px): [mô tả vấn đề]
Màn hình tablet (768px): [mô tả vấn đề]

Dùng Tailwind breakpoints: sm: md: lg: xl:
```

---

*File này cập nhật khi có thêm tính năng mới.*
*Thứ tự thực hiện: A1 → A2 → A3 → B1 → B2 → B3 → B4 → B5 → B6 → C1 → C2 → C3 → C4*
