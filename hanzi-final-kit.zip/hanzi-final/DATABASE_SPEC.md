# 📚 DATABASE SPEC — HANZI.IO.VN
# Dựa trên phân tích Tân HSK Giáo Trình 1, 2, 3 (New HSK Course — Ngoại ngữ xuất bản 2026)
# Tài liệu này đủ để agent khác đọc và code lại toàn bộ

---

## I. PHÂN TÍCH 3 GIÁO TRÌNH

### 📗 TÂN HSK GIÁO TRÌNH 1 (New HSK Course 1)
- **Đối tượng:** Người mới bắt đầu hoàn toàn / Ôn thi HSK cấp 1
- **Số bài:** 15 bài học (Lesson 1–15)
- **Từ vựng:** 300 từ (theo syllabus HSK 3.0 cấp 1) + mở rộng nhẹ
- **Ngữ pháp:** 40 điểm ngữ pháp
- **Thời lượng:** 30–36 tiết, mỗi bài 2–3 tiết
- **Cấu trúc mỗi bài:**
  - Mục tiêu (目标 Objectives)
  - Khởi động (热身 Warm-Up) — bài 4–15
  - Bắt chước đọc (跟读绕口令) — bài 1–3
  - 3 đoạn hội thoại (课文 Text 1, 2, 3) — tình huống giao tiếp
  - Tiểu ngữ giảng đường (小语讲堂 Xiaoyu's Classroom) — giải thích ngữ pháp
  - Bài tập tổng hợp (综合练习)
  - Hoạt động lớp học (课堂活动)
  - Trứng thưởng của Tiểu ngữ (小语的彩蛋) — 8 mục văn hóa
  - Tổng kết học tập (学习小结) — mỗi 3 bài

### 📘 TÂN HSK GIÁO TRÌNH 2 (New HSK Course 2)
- **Đối tượng:** Đã học ~300 từ / Ôn thi HSK cấp 2
- **Số bài:** 15 bài học
- **Từ vựng:** 200 từ mới (cộng dồn ~500 từ)
- **Ngữ pháp:** 45 điểm ngữ pháp
- **Thời lượng:** 30–45 tiết, mỗi bài 2–3 tiết
- **Cấu trúc mỗi bài:** Giống cấp 1, thêm:
  - 4 đoạn văn (3 hội thoại + 1 văn xuôi)
  - Warm-Up có 2 phần: ghép từ-ảnh + điền vào bảng

### 📙 TÂN HSK GIÁO TRÌNH 3 (New HSK Course 3)
- **Đối tượng:** Đã học ~500 từ / Ôn thi HSK cấp 3
- **Số bài:** 18 bài học
- **Từ vựng:** 500 từ theo syllabus cấp 3 + mở rộng
- **Ngữ pháp:** 63 điểm ngữ pháp
- **Thời lượng:** 54–72 tiết, mỗi bài 3–4 tiết
- **Cấu trúc mỗi bài:** Tương tự cấp 2, Warm-Up thêm hoạt động thảo luận ảnh

---

## II. DANH SÁCH BÀI HỌC THEO TỪNG CẤP

### 📗 HSK 1 — 15 bài
| # | Tên bài (ZH) | Tên bài (EN) | Ngữ pháp chính |
|---|---|---|---|
| 1 | AI小语，你好！| Hello, AI Xiaoyu! | (Giới thiệu chương trình) |
| 2 | 我叫李文 | My name is Li Wen | Trật tự từ cơ bản; 我叫... |
| 3 | 我是中国人 | I'm Chinese | Câu 是; Trợ từ 的; Câu hỏi 吗 |
| 4 | 我有两个孩子 | I have two children | Câu 有(1); Số đếm; 呢(1); Số lượng+lượng từ |
| 5 | 今天我休息 | I'm off today | Diễn đạt thời gian(1); Câu danh ngữ vị ngữ; 会 |
| 6 | 你的手机号是多少？| What's your phone number? | 想; Liên động câu(1); 怎么 |
| 7 | 我晚上六点半下班 | I'll finish work at 6:30 in the evening | Thời gian(2); 吧(1); Phó từ/thời gian làm trạng ngữ; 呢(2) |
| 8 | 我爸爸也在医院工作 | My father also works at a hospital | Phương vị từ; Giới từ 在; 能 |
| 9 | 我明天上午在学校学习 | I'll be studying at school tomorrow morning | Câu tồn tại(1); Thứ tự thời-địa; Số thứ tự 第 |
| 10 | 这儿的苹果真便宜！| The apples here are really affordable! | Diễn đạt tiền; Câu tính từ vị ngữ; 怎么样 |
| 11 | 我读大学呢 | I'm studying at university | Câu hỏi chính phản; 在/正在; 要 |
| 12 | 昨天下雪了 | It snowed yesterday | Câu phi chủ ngữ; 了(1); 太...了 |
| 13 | 请给我一杯茶 | I'll have a cup of tea, please | 可以; V+一+V; Câu hai tân ngữ(1) |
| 14 | 我看了一个电影 | I watched a movie | 了(2); Ly hợp từ(1); 都 |
| 15 | 大兴机场见！| See you at Daxing Airport! | Câu liên hợp ...还/也... |

### 📘 HSK 2 — 15 bài
| # | Tên bài (ZH) | Tên bài (EN) | Ngữ pháp chính |
|---|---|---|---|
| 1 | 她请我们吃了北京烤鸭 | She treated us to Peking Duck | 吧(2); 是...的; Câu kiêm ngữ |
| 2 | 还是打车去北大吧 | Let's take a taxi to Peking University instead | 还是...吧; 多+số; Động/danh ngữ làm định ngữ |
| 3 | 我想去西安旅游 | I want to visit Xi'an | Bổ ngữ kết quả; Trùng điệp động từ(1)(2) |
| 4 | 你穿红色的很好看 | You look pretty good in red | 过; Nhân quả 因为...所以...; 的字短语 |
| 5 | 第一次去中国朋友家 | Visiting a Chinese friend's home for the first time | Bổ ngữ hướng đơn giản(1)(2); 都...了 |
| 6 | 小雪，生日快乐！| Happy birthday, Xiaoxue! | Trùng điệp tính từ; 什么的; 地 |
| 7 | 他篮球打得很好 | He plays basketball very well | Câu phức tắt 一...就...; Bổ ngữ trạng thái(1)(2) |
| 8 | 虽然你忘了，但是我记得 | Even though you forgot, I remembered | So sánh(1)(2); 虽然...但是... |
| 9 | 我去买杯奶茶 | I'm going to buy a cup of bubble tea | So sánh(3); 离; Bổ ngữ thời lượng(1) |
| 10 | 就要考试了 | The exam is coming | Câu chủ vị làm vị ngữ; Câu hỏi lựa chọn; 要/快/就要...了 |
| 11 | 我最喜欢吃中国菜 | I like Chinese food the most | 着(1)(2); 最 |
| 12 | 这里比北京冷多了 | It's much colder here than in Beijing | So sánh(4)(5)(6) |
| 13 | 我们爱上中文课 | We love attending Chinese class | Câu hai tân ngữ(2); So sánh(7)(8) |
| 14 | 一个人过年多没意思啊 | It's boring to celebrate the Spring Festival alone | Câu tồn tại(2); 多; Bổ ngữ hướng phức hợp |
| 15 | 我想再去一次中国 | I want to go to China again | Bổ ngữ lần lượt(1)(2); 有字句(2) |

### 📙 HSK 3 — 18 bài
| # | Tên bài (ZH) | Tên bài (EN) | Ngữ pháp chính |
|---|---|---|---|
| 1 | 我们去机场接你们 | We will pick you up at the airport | 看上去/看起来; Đại từ nghi vấn dùng phi nghi vấn(1); Nhiều định ngữ |
| 2 | 你们想吃什么就点什么 | You can order whatever you feel like | 又...又...; Đại từ nghi vấn phi nghi vấn(2)(3) |
| 3 | 这个小区挺好的 | This neighborhood is pretty nice | 挺; Bổ ngữ trình độ(1); 就 và 才 |
| 4 | 这家宾馆跟别的都不一样 | This hotel is unlike any other | 一...也/都+不/没...; So sánh(9); 除了...(以外)...都/还/也 |
| 5 | 这样的照片才好看 | Photos like these are the best | Bổ ngữ trình độ(2); Trùng điệp lượng từ; Câu tồn tại(3); ...了...就... |
| 6 | 高铁上还可以点外卖 | You can even order takeout on a high-speed train | 该...了; 如果...就...; 越来越 |
| 7 | 那条裙子比短裤还好看 | That skirt looks better than the shorts | Liên động câu(2); So sánh(10); Bổ ngữ trình độ(3); 不但...而且... |
| 8 | 今天我出院了 | Today I was discharged from the hospital | Bổ ngữ hướng mở rộng(1); Ly hợp từ(2); Thời lượng(2); ...以前/以后/前/后 |
| 9 | 打不好没关系 | It doesn't matter if you don't play well | Câu mục đích 为了...; Bổ ngữ khả năng; 越A越B |
| 10 | 你明天再把书还给我 | You can return the book to me tomorrow | 把字句(1)(2); 在...上/中/下 |
| 11 | 看来我没办法解决这个问题 | It seems I can't solve this problem | 还是 vs 或者; 看来; 把字句(3); 对...来说 |
| 12 | 这个季节天气变化很快 | The weather changes rapidly in this season | 或者...或者...; Bổ ngữ hướng mở rộng(2)(3); 就 |
| 13 | 我的新邻居来自英国 | My new neighbors come from the UK | ......的话，就...; 把字句(4); 一边...一边... |
| 14 | 这本书被别人借走了 | This book is checked out | Bị động câu(1); 先...再/然后...; ×什么(啊) |
| 15 | 我是半个南京人 | I am basically half a Nanjing local | 根据; Trùng điệp số lượng từ; 在...看来; 不一会儿 |
| 16 | 我听说有的熊猫出国了 | I heard that some pandas have gone abroad | 一会儿...一会儿...; 关于; 一般来说; So sánh(11) |
| 17 | 我要多向认真的人学习 | I will learn from people who are careful | 向; 不是...吗?; ...更...; 只有...才... |
| 18 | 我学会了包饺子 | I've learned how to make jiaozi | Số ước; 刚才 vs 刚刚; 只要...就...; 从...起 |

---

## III. DATABASE SCHEMA — SUPABASE SQL

```sql
-- ══════════════════════════════════════════
-- 1. BOOKS (Giáo trình)
-- ══════════════════════════════════════════
CREATE TABLE books (
  id          SERIAL PRIMARY KEY,
  level       INTEGER NOT NULL,        -- 1, 2, 3
  title_zh    TEXT NOT NULL,           -- 新HSK教程1
  title_vi    TEXT NOT NULL,           -- Tân HSK Giáo Trình 1
  title_en    TEXT,                    -- New HSK Course 1
  total_lessons INTEGER,              -- 15, 15, 18
  total_words   INTEGER,              -- 300, 200, 500
  total_grammar INTEGER,              -- 40, 45, 63
  hours_min   INTEGER,                -- 30
  hours_max   INTEGER,                -- 36
  color_hex   TEXT DEFAULT '#E53E3E', -- màu chủ đạo UI
  description TEXT,
  is_active   BOOLEAN DEFAULT TRUE
);

INSERT INTO books (level,title_zh,title_vi,title_en,total_lessons,total_words,total_grammar,hours_min,hours_max,color_hex) VALUES
(1,'新HSK教程1','Tân HSK Giáo Trình 1','New HSK Course 1',15,300,40,30,36,'#E53E3E'),
(2,'新HSK教程2','Tân HSK Giáo Trình 2','New HSK Course 2',15,200,45,30,45,'#DD6B20'),
(3,'新HSK教程3','Tân HSK Giáo Trình 3','New HSK Course 3',18,500,63,54,72,'#D69E2E');

-- ══════════════════════════════════════════
-- 2. LESSONS (Bài học)
-- ══════════════════════════════════════════
CREATE TABLE lessons (
  id            SERIAL PRIMARY KEY,
  book_level    INTEGER NOT NULL REFERENCES books(level),
  lesson_number INTEGER NOT NULL,
  title_zh      TEXT NOT NULL,
  title_en      TEXT,
  title_vi      TEXT,
  page_start    INTEGER,
  is_free       BOOLEAN DEFAULT FALSE,  -- bài 1-3 miễn phí
  summary_vi    TEXT,                   -- tóm tắt nội dung
  UNIQUE(book_level, lesson_number)
);

-- HSK 1 lessons
INSERT INTO lessons (book_level,lesson_number,title_zh,title_en,title_vi,page_start,is_free) VALUES
(1,1,'AI小语，你好！','Hello, AI Xiaoyu!','Xin chào, AI Tiểu Ngữ!',1,TRUE),
(1,2,'我叫李文','My name is Li Wen','Tôi tên Li Wen',5,TRUE),
(1,3,'我是中国人','I''m Chinese','Tôi là người Trung Quốc',10,TRUE),
(1,4,'我有两个孩子','I have two children','Tôi có hai đứa con',18,FALSE),
(1,5,'今天我休息','I''m off today','Hôm nay tôi nghỉ',27,FALSE),
(1,6,'你的手机号是多少？','What''s your phone number?','Số điện thoại của bạn là bao nhiêu?',35,FALSE),
(1,7,'我晚上六点半下班','I''ll finish work at 6:30 in the evening','Tôi tan ca lúc 6 giờ rưỡi tối',45,FALSE),
(1,8,'我爸爸也在医院工作','My father also works at a hospital','Bố tôi cũng làm việc ở bệnh viện',54,FALSE),
(1,9,'我明天上午在学校学习','I''ll be studying at school tomorrow morning','Sáng mai tôi học ở trường',61,FALSE),
(1,10,'这儿的苹果真便宜！','The apples here are really affordable!','Táo ở đây thật rẻ!',70,FALSE),
(1,11,'我读大学呢','I''m studying at university','Tôi đang học đại học',78,FALSE),
(1,12,'昨天下雪了','It snowed yesterday','Hôm qua tuyết rơi',86,FALSE),
(1,13,'请给我一杯茶','I''ll have a cup of tea, please','Cho tôi một ly trà',95,FALSE),
(1,14,'我看了一个电影','I watched a movie','Tôi đã xem một bộ phim',103,FALSE),
(1,15,'大兴机场见！','See you at Daxing Airport!','Hẹn gặp ở sân bay Đại Hưng!',112,FALSE);

-- HSK 2 lessons
INSERT INTO lessons (book_level,lesson_number,title_zh,title_en,title_vi,page_start,is_free) VALUES
(2,1,'她请我们吃了北京烤鸭','She treated us to Peking Duck','Cô ấy mời chúng tôi ăn vịt quay Bắc Kinh',1,TRUE),
(2,2,'还是打车去北大吧','Let''s take a taxi to Peking University instead','Đi taxi đến Bắc Đại đi',10,TRUE),
(2,3,'我想去西安旅游','I want to visit Xi''an','Tôi muốn đi du lịch Tây An',19,TRUE),
(2,4,'你穿红色的很好看','You look pretty good in red','Bạn mặc đồ đỏ trông rất đẹp',29,FALSE),
(2,5,'第一次去中国朋友家','Visiting a Chinese friend''s home for the first time','Lần đầu tiên đến nhà bạn Trung Quốc',37,FALSE),
(2,6,'小雪，生日快乐！','Happy birthday, Xiaoxue!','Chúc mừng sinh nhật Tiểu Tuyết!',46,FALSE),
(2,7,'他篮球打得很好','He plays basketball very well','Anh ấy chơi bóng rổ rất giỏi',56,FALSE),
(2,8,'虽然你忘了，但是我记得','Even though you forgot, I remembered','Mặc dù bạn quên nhưng tôi nhớ',64,FALSE),
(2,9,'我去买杯奶茶','I''m going to buy a cup of bubble tea','Tôi đi mua trà sữa',73,FALSE),
(2,10,'就要考试了','The exam is coming','Sắp thi rồi',84,FALSE),
(2,11,'我最喜欢吃中国菜','I like Chinese food the most','Tôi thích ăn đồ Trung Quốc nhất',93,FALSE),
(2,12,'这里比北京冷多了','It''s much colder here than in Beijing','Ở đây lạnh hơn Bắc Kinh nhiều',102,FALSE),
(2,13,'我们爱上中文课','We love attending Chinese class','Chúng tôi thích học tiếng Trung',112,FALSE),
(2,14,'一个人过年多没意思啊','It''s boring to celebrate the Spring Festival alone','Một mình đón Tết thật buồn',121,FALSE),
(2,15,'我想再去一次中国','I want to go to China again','Tôi muốn đến Trung Quốc thêm một lần nữa',130,FALSE);

-- HSK 3 lessons
INSERT INTO lessons (book_level,lesson_number,title_zh,title_en,title_vi,page_start,is_free) VALUES
(3,1,'我们去机场接你们','We will pick you up at the airport','Chúng tôi sẽ ra sân bay đón các bạn',1,TRUE),
(3,2,'你们想吃什么就点什么','You can order whatever you feel like','Các bạn muốn ăn gì cứ gọi',10,TRUE),
(3,3,'这个小区挺好的','This neighborhood is pretty nice','Khu phố này khá đẹp',19,TRUE),
(3,4,'这家宾馆跟别的都不一样','This hotel is unlike any other','Khách sạn này khác hẳn những nơi khác',29,FALSE),
(3,5,'这样的照片才好看','Photos like these are the best','Ảnh kiểu này mới đẹp',38,FALSE),
(3,6,'高铁上还可以点外卖','You can even order takeout on a high-speed train','Trên tàu cao tốc còn có thể đặt đồ ăn',47,FALSE),
(3,7,'那条裙子比短裤还好看','That skirt looks better than the shorts','Cái váy đó đẹp hơn quần short',57,FALSE),
(3,8,'今天我出院了','Today I was discharged from the hospital','Hôm nay tôi ra viện',67,FALSE),
(3,9,'打不好没关系','It doesn''t matter if you don''t play well','Đánh không tốt cũng không sao',76,FALSE),
(3,10,'你明天再把书还给我','You can return the book to me tomorrow','Ngày mai bạn trả sách cho tôi',86,FALSE),
(3,11,'看来我没办法解决这个问题','It seems I can''t solve this problem','Có vẻ tôi không giải quyết được vấn đề này',95,FALSE),
(3,12,'这个季节天气变化很快','The weather changes rapidly in this season','Thời tiết mùa này thay đổi rất nhanh',104,FALSE),
(3,13,'我的新邻居来自英国','My new neighbors come from the UK','Hàng xóm mới của tôi đến từ Anh',115,FALSE),
(3,14,'这本书被别人借走了','This book is checked out','Cuốn sách này bị người khác mượn rồi',124,FALSE),
(3,15,'我是半个南京人','I am basically half a Nanjing local','Tôi cũng là người Nanjing một nửa',133,FALSE),
(3,16,'我听说有的熊猫出国了','I heard that some pandas have gone abroad','Tôi nghe nói một số gấu trúc ra nước ngoài',144,FALSE),
(3,17,'我要多向认真的人学习','I will learn from people who are careful','Tôi cần học hỏi những người cẩn thận',154,FALSE),
(3,18,'我学会了包饺子','I''ve learned how to make jiaozi','Tôi đã học được cách gói bánh bao',163,FALSE);

-- ══════════════════════════════════════════
-- 3. GRAMMAR POINTS (Điểm ngữ pháp)
-- ══════════════════════════════════════════
CREATE TABLE grammar_points (
  id            SERIAL PRIMARY KEY,
  book_level    INTEGER NOT NULL,
  lesson_number INTEGER NOT NULL,
  point_number  INTEGER NOT NULL,       -- thứ tự trong bài
  title_zh      TEXT NOT NULL,          -- 汉语的基本语序
  title_en      TEXT,                   -- Basic Word Order in Chinese
  title_vi      TEXT,                   -- Trật tự từ cơ bản trong tiếng Trung
  explanation_vi TEXT,                  -- giải thích chi tiết
  formula       TEXT,                   -- S + 是 + O
  examples      JSONB,                  -- [{zh:'...', pinyin:'...', vi:'...'}]
  common_errors JSONB,                  -- lỗi thường gặp
  hsk_relevance TEXT,                   -- liên quan thi HSK
  UNIQUE(book_level, lesson_number, point_number)
);

-- Mẫu 10 điểm ngữ pháp HSK 1
INSERT INTO grammar_points (book_level,lesson_number,point_number,title_zh,title_en,title_vi,formula,examples,explanation_vi) VALUES
(1,2,1,'汉语的基本语序','Basic Word Order in Chinese','Trật tự từ cơ bản trong tiếng Trung',
'S + V + O',
'[{"zh":"我学汉语。","pinyin":"Wǒ xué Hànyǔ.","vi":"Tôi học tiếng Trung."},{"zh":"她喜欢音乐。","pinyin":"Tā xǐhuān yīnyuè.","vi":"Cô ấy thích âm nhạc."}]'::jsonb,
'Trong tiếng Trung, trật tự câu cơ bản là: Chủ ngữ (S) + Vị ngữ (V) + Tân ngữ (O). Đây là cấu trúc nền tảng quan trọng nhất.'),

(1,3,1,'"是"字句','"是" Sentence','Câu dùng "是"',
'S + 是 + O',
'[{"zh":"我是学生。","pinyin":"Wǒ shì xuéshēng.","vi":"Tôi là học sinh."},{"zh":"他是中国人。","pinyin":"Tā shì Zhōngguórén.","vi":"Anh ấy là người Trung Quốc."}]'::jsonb,
'Động từ 是 dùng để khẳng định đồng nhất. Phủ định: 不是. Câu hỏi: ...是...吗?'),

(1,3,2,'结构助词"的"','Structural Particle "的"','Trợ từ kết cấu "的"',
'A + 的 + B (A sở hữu B)',
'[{"zh":"我的书","pinyin":"wǒ de shū","vi":"sách của tôi"},{"zh":"她的名字","pinyin":"tā de míngzi","vi":"tên của cô ấy"}]'::jsonb,
'的 dùng giữa người sở hữu và vật được sở hữu. Có thể lược bỏ khi quan hệ thân thiết (爸爸妈妈 không cần 的).'),

(1,3,3,'用"吗"的是非问句','Yes-No Question with "吗"','Câu hỏi Yes/No dùng "吗"',
'S + V + O + 吗？',
'[{"zh":"你是学生吗？","pinyin":"Nǐ shì xuéshēng ma?","vi":"Bạn có phải là học sinh không?"},{"zh":"你喝茶吗？","pinyin":"Nǐ hē chá ma?","vi":"Bạn uống trà không?"}]'::jsonb,
'Thêm 吗 vào cuối câu khẳng định để tạo câu hỏi Yes/No. Trả lời: Có = lặp lại động từ; Không = 不+động từ.'),

(1,4,1,'"有"字句（1）','"有" Sentence (1)','Câu dùng 有 (1)',
'S + 有 + O',
'[{"zh":"我有一个哥哥。","pinyin":"Wǒ yǒu yī gè gēgē.","vi":"Tôi có một anh trai."},{"zh":"他没有钱。","pinyin":"Tā méiyǒu qián.","vi":"Anh ấy không có tiền."}]'::jsonb,
'有 diễn đạt sở hữu. Phủ định bắt buộc dùng 没有 (KHÔNG dùng 不有). Câu hỏi: ...有...吗?'),

(1,5,1,'时间的表达（1）','Expression of Time (1)','Diễn đạt thời gian (1)',
'Năm + Tháng + Ngày + Thứ + Giờ',
'[{"zh":"二零二五年三月十五日，星期六，上午九点","pinyin":"2025 nián 3 yuè 15 rì, xīngqī liù, shàngwǔ jiǔ diǎn","vi":"Ngày 15 tháng 3 năm 2025, thứ Bảy, 9 giờ sáng"}]'::jsonb,
'Tiếng Trung đọc thời gian từ đơn vị lớn đến nhỏ. Giờ: X点 | Phút: X分 | Rưỡi: 半 | Kém: 差X分X点.'),

(1,6,1,'能愿动词"想"','Modal Verb "想"','Động từ tình thái 想',
'S + 想 + V',
'[{"zh":"我想去中国。","pinyin":"Wǒ xiǎng qù Zhōngguó.","vi":"Tôi muốn đến Trung Quốc."},{"zh":"你想喝什么？","pinyin":"Nǐ xiǎng hē shénme?","vi":"Bạn muốn uống gì?"}]'::jsonb,
'想 diễn đạt mong muốn, ý định. Phủ định: 不想. So sánh: 想 (muốn) vs 要 (cần, sẽ) vs 会 (có thể).'),

(1,8,1,'方位词','Positional Words','Phương vị từ',
'名词 + 上/下/前/后/里/外/左/右/旁边/中间',
'[{"zh":"桌子上","pinyin":"zhuōzi shàng","vi":"trên bàn"},{"zh":"门后面","pinyin":"mén hòumiàn","vi":"sau cửa"},{"zh":"两个人中间","pinyin":"liǎng gè rén zhōngjiān","vi":"giữa hai người"}]'::jsonb,
'Phương vị từ đứng sau danh từ để chỉ vị trí. Luôn đi kèm với 在: 书在桌子上 (Sách ở trên bàn).'),

(1,11,1,'正反问','Affirmative-Negative Questions','Câu hỏi chính phản',
'S + V不V + O? hoặc S + V没V + O?',
'[{"zh":"你是不是学生？","pinyin":"Nǐ shì bu shì xuéshēng?","vi":"Bạn có phải học sinh không?"},{"zh":"你去不去？","pinyin":"Nǐ qù bu qù?","vi":"Bạn có đi không?"}]'::jsonb,
'Câu hỏi chính phản = Dạng khẳng định + Dạng phủ định. Không dùng 吗 cùng lúc với cấu trúc này.'),

(1,13,1,'能愿动词"可以"','Modal Verb "可以"','Động từ tình thái 可以',
'S + 可以 + V',
'[{"zh":"这里可以拍照吗？","pinyin":"Zhèlǐ kěyǐ pāizhào ma?","vi":"Ở đây có thể chụp ảnh không?"},{"zh":"你可以帮我吗？","pinyin":"Nǐ kěyǐ bāng wǒ ma?","vi":"Bạn có thể giúp tôi không?"}]'::jsonb,
'可以 = được phép làm; 能 = có khả năng làm. Phủ định: 不可以 (không được phép) vs 不能 (không thể/không có khả năng).');

-- ══════════════════════════════════════════
-- 4. VOCABULARY (Từ vựng)
-- ══════════════════════════════════════════
CREATE TABLE vocabulary (
  id              SERIAL PRIMARY KEY,
  book_level      INTEGER,              -- 1,2,3 (null nếu từ chủ đề)
  lesson_number   INTEGER,
  word_number     INTEGER,              -- số thứ tự trong bài
  hanzi           TEXT NOT NULL,
  pinyin          TEXT NOT NULL,
  meaning_vi      TEXT NOT NULL,
  meaning_en      TEXT,
  part_of_speech  TEXT,                 -- n./v./adj./adv./prep./conj./pron./num./mw./part.
  hsk_level       INTEGER,              -- cấp HSK chính thức
  topic           TEXT,                 -- 'family'|'food'|'work'...
  topic_lesson    INTEGER,
  example_zh      TEXT,
  example_pinyin  TEXT,
  example_vi      TEXT,
  image_url       TEXT,
  audio_url       TEXT,
  notes           TEXT,                 -- ghi chú đặc biệt
  UNIQUE(book_level, lesson_number, word_number)
);

-- ══════════════════════════════════════════
-- 5. TEXTS / DIALOGUES (Bài đọc / Hội thoại)
-- ══════════════════════════════════════════
CREATE TABLE texts (
  id            SERIAL PRIMARY KEY,
  book_level    INTEGER NOT NULL,
  lesson_number INTEGER NOT NULL,
  text_number   INTEGER NOT NULL,       -- 1,2,3 (hoặc 4 với cấp 2,3)
  type          TEXT NOT NULL,          -- 'dialogue' | 'narrative'
  scene_zh      TEXT,                   -- mô tả tình huống tiếng Trung
  scene_en      TEXT,
  scene_vi      TEXT,
  content       JSONB NOT NULL,         -- [{speaker:'王一飞', zh:'...', pinyin:'...', vi:'...'}]
  audio_ref     TEXT,                   -- ví dụ: '1-5' (bài 1, track 5)
  new_words     JSONB,                  -- [{number:9, zh:'谢谢', pinyin:'xièxie', pos:'v.', en:'thank you'}]
  UNIQUE(book_level, lesson_number, text_number)
);

-- ══════════════════════════════════════════
-- 6. CULTURAL NOTES (Trứng thưởng văn hóa)
-- ══════════════════════════════════════════
CREATE TABLE cultural_notes (
  id            SERIAL PRIMARY KEY,
  book_level    INTEGER NOT NULL,
  lesson_number INTEGER NOT NULL,
  title_zh      TEXT,
  title_vi      TEXT,
  content_zh    TEXT,
  content_vi    TEXT,
  image_url     TEXT,
  type          TEXT  -- 'culture' | 'language_tip' | 'bonus'
);

-- ══════════════════════════════════════════
-- 7. EXERCISES (Bài tập)
-- ══════════════════════════════════════════
CREATE TABLE exercises (
  id            SERIAL PRIMARY KEY,
  book_level    INTEGER NOT NULL,
  lesson_number INTEGER NOT NULL,
  type          TEXT NOT NULL,          -- 'choice_meaning'|'choice_pinyin'|'fill_blank'|'sort_words'|'flashcard'|'listening'|'typing'|'comprehensive'
  question_data JSONB NOT NULL,
  answer_data   JSONB NOT NULL,
  difficulty    INTEGER DEFAULT 1,      -- 1=dễ, 2=tb, 3=khó
  xp_reward     INTEGER DEFAULT 10,
  is_free       BOOLEAN DEFAULT FALSE
);

-- ══════════════════════════════════════════
-- 8. USER DATA
-- ══════════════════════════════════════════
CREATE TABLE user_progress (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       TEXT NOT NULL,          -- Clerk user ID
  content_type  TEXT NOT NULL,          -- 'lesson'|'exercise'|'reading'|'exam'
  book_level    INTEGER,
  lesson_number INTEGER,
  content_id    INTEGER,
  status        TEXT DEFAULT 'not_started', -- 'not_started'|'in_progress'|'completed'
  score         INTEGER DEFAULT 0,
  time_spent    INTEGER DEFAULT 0,      -- giây
  completed_at  TIMESTAMPTZ,
  UNIQUE(user_id, content_type, book_level, lesson_number)
);

CREATE TABLE user_vocabulary (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       TEXT NOT NULL,
  vocab_id      INTEGER REFERENCES vocabulary(id),
  ease_factor   FLOAT DEFAULT 2.5,
  interval_days INTEGER DEFAULT 1,
  repetitions   INTEGER DEFAULT 0,
  next_review   DATE DEFAULT CURRENT_DATE,
  last_rating   TEXT,                   -- 'hard'|'ok'|'easy'
  UNIQUE(user_id, vocab_id)
);

CREATE TABLE user_streaks (
  user_id         TEXT PRIMARY KEY,
  current_streak  INTEGER DEFAULT 0,
  longest_streak  INTEGER DEFAULT 0,
  last_active     DATE,
  total_xp        INTEGER DEFAULT 0,
  total_words     INTEGER DEFAULT 0,
  total_lessons   INTEGER DEFAULT 0
);

CREATE TABLE subscriptions (
  user_id     TEXT PRIMARY KEY,
  plan        TEXT DEFAULT 'free',      -- 'free'|'pro'|'live'
  expires_at  TIMESTAMPTZ,
  sepay_ref   TEXT,
  status      TEXT DEFAULT 'active'
);

-- Indexes
CREATE INDEX idx_vocab_level_lesson ON vocabulary(book_level, lesson_number);
CREATE INDEX idx_progress_user ON user_progress(user_id);
CREATE INDEX idx_vocab_user ON user_vocabulary(user_id, next_review);

-- RLS
ALTER TABLE vocabulary ENABLE ROW LEVEL SECURITY;
ALTER TABLE lessons ENABLE ROW LEVEL SECURITY;
ALTER TABLE texts ENABLE ROW LEVEL SECURITY;
ALTER TABLE grammar_points ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_vocabulary ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_streaks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "public_read_vocab" ON vocabulary FOR SELECT USING (TRUE);
CREATE POLICY "public_read_lessons" ON lessons FOR SELECT USING (TRUE);
CREATE POLICY "public_read_texts" ON texts FOR SELECT USING (TRUE);
CREATE POLICY "public_read_grammar" ON grammar_points FOR SELECT USING (TRUE);
CREATE POLICY "user_own_progress" ON user_progress USING (user_id = auth.jwt()->>'sub');
CREATE POLICY "user_own_vocab" ON user_vocabulary USING (user_id = auth.jwt()->>'sub');
CREATE POLICY "user_own_streak" ON user_streaks USING (user_id = auth.jwt()->>'sub');
```

---

## IV. CURRICULUM MAPPING — CẤU TRÚC MỖI BÀI HỌC TRÊN WEB

Mỗi bài học = 1 URL `/giao-trinh/hsk[N]/bai-[X]`

### Các tab nội dung (theo thứ tự giáo trình):
```
Tab 1: 📖 Từ vựng mới      — danh sách vocab + audio + ảnh + ví dụ câu
Tab 2: 📝 Bài đọc / Hội thoại — 3-4 đoạn text với audio
Tab 3: 🧠 Ngữ pháp          — các điểm ngữ pháp với giải thích + ví dụ
Tab 4: 🃏 Flashcard          — SRS với SM-2 algorithm
Tab 5: ✅ Chọn nghĩa         — quiz chọn nghĩa tiếng Việt
Tab 6: 🔤 Chọn phiên âm      — quiz chọn pinyin đúng
Tab 7: 📝 Điền từ           — điền vào chỗ trống trong câu
Tab 8: 👂 Luyện nghe        — nghe audio chọn đáp án
Tab 9: ⌨️ Nhập từ          — gõ chữ Hán / pinyin
Tab 10: 🎯 Tổng hợp         — bài tập kết hợp 5 kỹ năng
```

### Thứ tự học đề xuất:
```
Từ vựng → Bài đọc → Ngữ pháp → Flashcard → Chọn nghĩa → Chọn pinyin → Điền từ → Luyện nghe → Nhập từ → Tổng hợp
```

---

## V. TÍCH HỢP AUDIO

Sách gốc có audio track. Web sẽ dùng:
1. **Google TTS (Cloud Text-to-Speech)** — giọng zh-CN-Standard-C (nữ) hoặc zh-CN-Standard-B (nam)
2. **Tốc độ đề xuất:** 0.85 (chậm hơn tự nhiên để học)
3. **API route:** `POST /api/tts { text: string, slow?: boolean }`
4. **Cache:** Lưu file mp3 vào Supabase Storage để tránh gọi API nhiều lần

---

## VI. FREEMIUM GATE

| Nội dung | Free | Pro |
|----------|------|-----|
| Bài 1-3 mỗi cấp | ✅ đầy đủ | ✅ |
| Bài 4+ mỗi cấp | ❌ overlay khóa | ✅ |
| Flashcard SRS | ❌ | ✅ |
| Audio phát âm | ✅ 3 lần/ngày | ✅ không giới hạn |
| Tải tiến độ | ❌ | ✅ |
| Luyện nghe | ❌ | ✅ |
| Nhập từ | ❌ | ✅ |
| Luyện thi | ❌ | ✅ |

---

## VII. TỔNG TỪ VỰNG CẦN NHẬP

| Cấp | Từ trong sách | Ưu tiên nhập trước |
|-----|----------|-------------------|
| HSK 1 | 300 | ✅ Bài 1-5 (100 từ) |
| HSK 2 | 200 | ✅ Bài 1-5 (70 từ) |
| HSK 3 | 500 | Bài 1-3 (50 từ) |
| **Tổng** | **1000** | **220 từ MVP** |

Script import: `node scripts/import-all.js`

---

*File này được tạo bởi Claude dựa trên phân tích trực tiếp 3 PDF giáo trình New HSK Course 1, 2, 3 (NXB Ngoại ngữ, 2026)*
*Cập nhật lần cuối: 2026-04*
