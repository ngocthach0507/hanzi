# 📋 CURSOR-PROMPTS V3 — HANZI.IO.VN
# Dựa trên phân tích trực tiếp giáo trình Tân HSK 1, 2, 3
# NHẤN MẠNH HSK 3.0 — đây là USP chính của web

---

## ═══════════════════════════════════
## NHÓM A: DATABASE (chạy trước)
## ═══════════════════════════════════

### [A1] Chạy SQL schema trong Supabase SQL Editor
Paste toàn bộ nội dung từ file DATABASE_SPEC.md phần III vào Supabase SQL Editor và Run.

### [A2] Import data
```bash
node scripts/import-all.js
```

---

## ═══════════════════════════════════
## NHÓM B: TRANG CHỦ — HSK 3.0 LÀ TRUNG TÂM
## ═══════════════════════════════════

### [B1] Hero Section — nhấn mạnh HSK 3.0
```
Tạo app/page.tsx — Trang chủ hanzi.io.vn

HERO SECTION (ưu tiên cao nhất):
- Badge nổi bật: "🆕 Tân HSK 3.0 — Giáo Trình Mới Nhất 2026"
- H1: "Học tiếng Trung theo\nchuẩn <span màu đỏ>HSK 3.0</span> mới nhất"
- Sub: "Giáo trình Tân HSK của Hanban/CTI — bộ sách chính thức duy nhất chuẩn HSK 3.0. Phương pháp lấy học viên làm trung tâm, tích hợp AI."
- 2 CTA: [Bắt đầu học HSK 3.0 →] (đỏ) + [Xem giáo trình] (outline)

SECTION 2 — "Tại sao chọn HSK 3.0?":
3 card giải thích:
  📚 "Giáo trình chính thức" — Bộ sách duy nhất được Hanban/CTI phê duyệt, chuẩn 2026
  🤖 "Tích hợp AI" — AI Tiểu Ngữ hỗ trợ học mọi lúc, luyện phát âm, gợi ý cá nhân hóa
  🎯 "Lộ trình rõ ràng" — HSK 1→6, từ 0 đến thành thạo, cam kết kết quả

SECTION 3 — Grid 3 cấp độ HSK (card to, hấp dẫn):
  HSK 1 — màu đỏ #E53E3E — 15 bài — 300 từ — "Giao tiếp cơ bản" — [Học ngay]
  HSK 2 — màu cam #DD6B20 — 15 bài — 200 từ mới — "Hội thoại thông dụng" — [Học ngay]
  HSK 3 — màu vàng #D69E2E — 18 bài — 500 từ mới — "Giao tiếp tự nhiên" — [Học ngay]
  (HSK 4,5,6 — badge "Sắp ra mắt" — grayout)

SECTION 4 — Grid 11 mục (nhỏ hơn, phụ trợ):
Giáo trình HSK | Từ vựng chủ đề | Hội thoại | Đọc hiểu | Luyện thi | Bộ thủ | Dịch | Mẫu câu | Luyện viết | Lượng từ | Luyện đề THPT

SECTION 5 — Social proof: 48,000+ học viên, 4.9⭐, HSK 1-3 đầy đủ
```

### [B2] Navbar với HSK 3.0 badge
```
Tạo/cập nhật components/Navbar.tsx

THAY ĐỔI QUAN TRỌNG:
- Menu item "GT hán ngữ" → đổi thành "📖 HSK 3.0" với badge "NEW" màu đỏ nhỏ
- Khi hover "HSK 3.0": dropdown hiện 3 cấp (HSK 1, HSK 2, HSK 3) mỗi cấp có màu riêng
- Nút "Nâng cấp" vàng → thêm text nhỏ "từ 99k/tháng"

Dropdown "HSK 3.0":
  📗 HSK 1 — Cơ bản (300 từ) → /giao-trinh/hsk1
  📘 HSK 2 — Trung cấp (+200 từ) → /giao-trinh/hsk2
  📙 HSK 3 — Nâng cao (+500 từ) → /giao-trinh/hsk3
  --- separator ---
  📖 Xem tổng quan giáo trình → /giao-trinh
```

---

## ═══════════════════════════════════
## NHÓM C: GIÁO TRÌNH HSK 3.0 — TRANG CHÍNH
## ═══════════════════════════════════

### [C1] Trang tổng quan giáo trình /giao-trinh
```
Tạo app/giao-trinh/page.tsx

Header section nổi bật:
- Badge: "新HSK教程 · NXB Ngoại ngữ · Xuất bản 2026"
- H1: "Tân HSK Giáo Trình (Cấp 1–3)"  
- Sub: "Bộ giáo trình chính thức chuẩn HSK 3.0 của Hanban, được biên soạn bởi các chuyên gia hàng đầu Trung Quốc. Tích hợp AI Tiểu Ngữ — trợ lý học tập thông minh."

3 card cấp độ (layout ngang, có màu nền riêng):

[HSK 1 — nền đỏ nhạt #FFF5F5]
  Icon: 📗 + số "1"
  Badge: "Cơ bản · HSK 3.0"
  Tên: Tân HSK Giáo Trình 1 / 新HSK教程1
  Thông tin: 15 bài học · 300 từ vựng · 40 điểm ngữ pháp · 30–36 tiết
  Mô tả: "Dành cho người bắt đầu hoàn toàn. Học chào hỏi, giới thiệu bản thân, giao tiếp cơ bản hàng ngày."
  3 từ mẫu: 你好 · 谢谢 · 再见
  [Vào học →]

[HSK 2 — nền cam nhạt #FFFAF0]
  Tương tự, 15 bài · 200 từ mới · 45 điểm ngữ pháp · 30–45 tiết
  Mô tả: "Dành cho người đã có ~300 từ. Học hội thoại, mua sắm, du lịch, biểu đạt tình cảm."
  3 từ mẫu: 比较 · 虽然 · 已经

[HSK 3 — nền vàng nhạt #FFFFF0]
  18 bài · 500 từ mới · 63 điểm ngữ pháp · 54–72 tiết
  Mô tả: "Dành cho người đã có ~500 từ. Học biểu đạt phức tạp, câu bị động, ngữ pháp nâng cao."
  3 từ mẫu: 越来越 · 虽然 · 把字句

Data từ Supabase bảng books.
```

### [C2] Danh sách bài học — /giao-trinh/hsk[N]
```
Tạo app/giao-trinh/hsk[level]/page.tsx — dynamic route

Layout:
- Breadcrumb: Trang chủ > Giáo trình HSK 3.0 > HSK {level}
- Header: tên sách tiếng Việt + tiếng Trung, stats (bài/từ/ngữ pháp/tiết)
- Màu chủ đạo theo level: 1=đỏ, 2=cam, 3=vàng

Danh sách bài dạng card list (không phải grid):
Mỗi bài:
  - Số bài (to, màu level)
  - Tiêu đề tiếng Trung (font lớn)
  - Tiêu đề tiếng Việt (nhỏ hơn, xám)
  - Số từ mới + số điểm ngữ pháp
  - Status: Chưa học / Đang học X% / ✓ Hoàn thành / 🔒 Pro
  - Progress bar
  - [Vào học] hoặc [🔒 Nâng cấp]

Phân nhóm theo cụm 3 bài (mỗi 3 bài có 学习小结):
Bài 1–3 (+ Tổng kết 1) | Bài 4–6 (+ Tổng kết 2) | ...

Data từ Supabase: SELECT * FROM lessons WHERE book_level={level} ORDER BY lesson_number
User progress từ Clerk userId → user_progress table
```

### [C3] Nội dung bài học — /giao-trinh/hsk[N]/bai-[X]
```
Tạo app/giao-trinh/hsk[level]/[lesson]/page.tsx

Layout CHÍNH:
- Header: "Bài {N}: {title_zh}" + "{title_vi}" + màu theo level
- Breadcrumb
- Tabs ngang (10 tab):
  [📖 Từ vựng] [📝 Bài đọc] [🧠 Ngữ pháp] [🃏 Flashcard] [✅ Chọn nghĩa] [🔤 Chọn pinyin] [📝 Điền từ] [👂 Luyện nghe] [⌨️ Nhập từ] [🎯 Tổng hợp]

Tab "Từ vựng" (mặc định):
- Section "Từ mới trong bài" — grid 2 cột:
  Mỗi từ card:
    Số thứ tự (vòng tròn màu) | Chữ Hán (text-3xl, serif) | Pinyin (đỏ/cam/vàng tùy level) | Loại từ badge (n./v./adj...) | Nghĩa tiếng Việt | Nút 🔊
    Câu ví dụ: ZH (có pinyin nhỏ trên đầu từng chữ) + VI
    Nút [+ Thêm vào bộ ôn tập]

Tab "Bài đọc":
- Hiển thị 3 đoạn hội thoại (cấp 1) hoặc 4 đoạn (cấp 2, 3)
- Mỗi đoạn: mô tả tình huống + bubble chat + bảng từ mới trong đoạn + nút nghe
- Nút [▶ Nghe toàn bộ]

Tab "Ngữ pháp":
- Thẻ card từng điểm ngữ pháp:
  Tên ngữ pháp (ZH + VI) | Công thức (nổi bật) | Giải thích | 3 ví dụ câu | Lỗi thường gặp

Layout PHỤ (sidebar bên phải 1/4 màn hình):
- Danh sách tất cả bài của cấp đó
- Highlight bài hiện tại
- Progress từng bài

Navigation footer: [← Bài trước] [Bài sau →]
Float button: [▶ Luyện tập] → chuyển đến tab Flashcard

Data:
vocabulary: WHERE book_level={level} AND lesson_number={lesson}
texts: WHERE book_level={level} AND lesson_number={lesson}
grammar_points: WHERE book_level={level} AND lesson_number={lesson}
```

### [C4] Flashcard với SM-2 SRS
```
Tạo app/giao-trinh/hsk[level]/[lesson]/flashcard/page.tsx

UI:
- Header: "Bài {N} · Flashcard · {X} thẻ"
- Progress: {done}/{total} + XP hiện tại
- Thẻ lớn có flip animation 3D:
  MẶT TRƯỚC: Chữ Hán cực lớn (text-8xl, font-serif) + pinyin mờ (click để hiện) + nút 🔊
  MẶT SAU: Pinyin đỏ lớn + Nghĩa VI + Loại từ badge + Câu ví dụ đầy đủ
- Click thẻ hoặc Space → flip
- Sau khi flip: 3 nút đánh giá:
  [😅 Khó - 1] [🙂 Ổn - 2] [😄 Dễ - 3]
- Màu nút theo level: 1=đỏ, 2=cam, 3=vàng

SRS Algorithm (SM-2) trong lib/srs.ts:
function sm2(ef: number, interval: number, reps: number, rating: 1|2|3) {
  if (rating === 1) return { ef: Math.max(1.3, ef-0.2), interval: 1, reps: 0, nextDays: 1 }
  const newReps = reps + 1
  const newInterval = reps === 0 ? 1 : reps === 1 ? 6 : Math.round(interval * ef)
  const newEf = rating === 3 ? ef + 0.1 : ef
  return { ef: newEf, interval: newInterval, reps: newReps, nextDays: newInterval }
}

Kết thúc: màn hình kết quả với stats + nút tiếp theo
```

### [C5] Quiz Chọn nghĩa
```
Tạo app/giao-trinh/hsk[level]/[lesson]/chon-nghia/page.tsx

10 câu hỏi, mỗi câu:
- Hiển thị: Chữ Hán lớn + pinyin
- 4 đáp án: 1 đúng + 3 sai (random từ cùng level)
- Timeout 30 giây mỗi câu (progress bar đếm ngược)
- Kết quả: đúng → +10 XP + confetti; sai → giải thích

Progress bar câu, điểm XP realtime, streak counter
```

### [C6] Bài tập Điền từ
```
Tạo app/giao-trinh/hsk[level]/[lesson]/dien-tu/page.tsx

Lấy câu ví dụ từ vocabulary, ẩn 1 từ → điền vào blank
Chấp nhận: Chữ Hán HOẶC Pinyin (so sánh chuẩn hóa)
Gợi ý: số nét, ký tự đầu pinyin (có thể toggle)
Chấm điểm: đúng hoàn toàn / gần đúng (thiếu dấu) / sai
```

---

## ═══════════════════════════════════
## NHÓM D: CÁC MỤC KHÁC (giữ nguyên từ V2)
## ═══════════════════════════════════

### [D1] Từ vựng chủ đề /tu-vung-chu-de
Giữ nguyên từ CURSOR-PROMPTS-V2.md [D1] [D2]

### [D2] Hội thoại /hoi-thoai
Giữ nguyên từ CURSOR-PROMPTS-V2.md [E1] [E2]

### [D3] Đọc hiểu /doc-hieu
Giữ nguyên từ CURSOR-PROMPTS-V2.md [F1]

### [D4] Luyện thi /luyen-thi
Giữ nguyên từ CURSOR-PROMPTS-V2.md [G1]

### [D5] Bộ thủ /bo-thu
Giữ nguyên từ CURSOR-PROMPTS-V2.md [H1]

### [D6] Dịch /dich
Giữ nguyên từ CURSOR-PROMPTS-V2.md [I1]

### [D7] Mẫu câu /mau-cau
Giữ nguyên từ CURSOR-PROMPTS-V2.md [J1]

### [D8] Luyện viết /luyen-viet
Giữ nguyên từ CURSOR-PROMPTS-V2.md [K1]

### [D9] Lượng từ /luong-tu
Giữ nguyên từ CURSOR-PROMPTS-V2.md [L1]

### [D10] Luyện đề THPT /luyen-de-thpt
Giữ nguyên từ CURSOR-PROMPTS-V2.md [M1]

---

## ═══════════════════════════════════
## NHÓM E: DASHBOARD & THANH TOÁN
## ═══════════════════════════════════

### [E1] Dashboard
Giữ nguyên từ CURSOR-PROMPTS-V2.md [N1]
Thêm: Section "Lộ trình HSK 3.0 của bạn" — 3 progress bar màu sắc theo level

### [E2] Trang nâng cấp /nang-cap
```
Tạo app/nang-cap/page.tsx

Hero: "Mở khóa toàn bộ giáo trình HSK 3.0 🎓"
Sub: "Học theo chuẩn mới nhất 2026, tích hợp AI, lộ trình đầy đủ HSK 1-3"

3 gói:
MIỄN PHÍ:
  0₫ mãi mãi
  Bài 1-3 mỗi cấp (9 bài)
  Từ vựng + hội thoại cơ bản
  Flashcard cơ bản (5 thẻ/ngày)
  ✗ Ngữ pháp chi tiết
  ✗ Bài tập đầy đủ (10 loại)
  ✗ Luyện nghe + Nhập từ
  ✗ SRS không giới hạn

PRO (highlight — border đỏ — badge "Phổ biến"):
  99,000₫/tháng hoặc 69,000₫/tháng (năm)
  Toàn bộ HSK 1+2+3 (48 bài)
  Tất cả 10 loại bài tập
  SRS không giới hạn
  Audio phát âm không giới hạn
  Ngữ pháp giải thích chi tiết
  Theo dõi tiến độ đầy đủ
  ✗ Live class

PRO + LIVE:
  199,000₫/tháng hoặc 139,000₫/tháng (năm)
  Tất cả Pro
  Live class 2 buổi/tuần với giáo viên bản ngữ
  Nhóm học viên VIP
  Chứng chỉ hoàn thành
  Hỗ trợ 24/7

Thanh toán: SePay (đã có integration từ PROJECT_HANDOVER)
POST /api/payment/create → SePay → webhook /api/payment/webhook
```

---

## ═══════════════════════════════════
## NHÓM F: API ROUTES
## ═══════════════════════════════════

### [F1] Tất cả API routes cần thiết
```
Tạo các file sau (Next.js App Router):

app/api/
  tts/route.ts                    — POST {text} → Google TTS hoặc browser fallback
  vocabulary/[id]/rate/route.ts   — PATCH {userId, rating} → cập nhật SRS
  progress/update/route.ts        — POST {userId, bookLevel, lesson, score} → update + streak
  payment/create/route.ts         — POST {plan, cycle} → SePay payment link
  payment/webhook/route.ts        — POST (từ SePay) → verify + update subscription
  search/route.ts                 — GET ?q={query} → tìm từ vựng + bài học
```

---

## ═══════════════════════════════════
## NHÓM G: IMPORT DATA
## ═══════════════════════════════════

### [G1] Script import đầy đủ
```javascript
// scripts/import-all.js
const { createClient } = require('@supabase/supabase-js')
require('dotenv').config({ path: '.env.local' })

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
)

async function importTable(table, data, clearFilter) {
  if (clearFilter) await supabase.from(table).delete().match(clearFilter)
  for (let i = 0; i < data.length; i += 50) {
    const { error } = await supabase.from(table).insert(data.slice(i, i+50))
    if (error) console.error(`❌ ${table} batch ${i}:`, error.message)
    else console.log(`✅ ${table}: ${i+Math.min(50,data.length-i)} records`)
  }
}

async function main() {
  // Books
  await importTable('books', require('../data/books.json'))
  // Lessons
  await importTable('lessons', require('../data/lessons-hsk1.json'), { book_level: 1 })
  await importTable('lessons', require('../data/lessons-hsk2.json'), { book_level: 2 })
  await importTable('lessons', require('../data/lessons-hsk3.json'), { book_level: 3 })
  // Vocabulary
  await importTable('vocabulary', require('../data/vocab-hsk1-l1-5.json'))
  await importTable('vocabulary', require('../data/vocab-hsk2-l1-3.json'))
  // Grammar
  await importTable('grammar_points', require('../data/grammar-hsk1.json'))
  // Texts/Dialogues
  await importTable('texts', require('../data/texts-hsk1.json'))
  // Topics
  await importTable('topics', require('../data/topics.json'))
  await importTable('vocabulary', require('../data/topic-vocab.json'))
  // Conversations, readings, etc.
  await importTable('conversations', require('../data/conversations.json'))
  await importTable('readings', require('../data/readings.json'))
  await importTable('radicals', require('../data/radicals.json'))
  await importTable('sentence_patterns', require('../data/sentence-patterns.json'))
  await importTable('measure_words', require('../data/measure-words.json'))
  await importTable('exams', require('../data/exams.json'))
  console.log('🎉 Import hoàn tất!')
}

main().catch(console.error)
```

---

## ═══════════════════════════════════
## NHÓM H: MÀU SẮC & DESIGN SYSTEM
## ═══════════════════════════════════

### [H1] Design tokens theo HSK level
```css
/* globals.css hoặc tailwind.config.ts */

/* Level colors */
--hsk1-primary: #E53E3E;    /* đỏ */
--hsk1-light:   #FFF5F5;
--hsk1-medium:  #FC8181;

--hsk2-primary: #DD6B20;    /* cam */
--hsk2-light:   #FFFAF0;
--hsk2-medium:  #F6AD55;

--hsk3-primary: #D69E2E;    /* vàng */
--hsk3-light:   #FFFFF0;
--hsk3-medium:  #F6E05E;

/* Brand */
--brand-red:    #D85A30;    /* màu logo hanzi.io.vn */

/* Tailwind thêm vào config */
extend: {
  colors: {
    hsk1: { DEFAULT: '#E53E3E', light: '#FFF5F5' },
    hsk2: { DEFAULT: '#DD6B20', light: '#FFFAF0' },
    hsk3: { DEFAULT: '#D69E2E', light: '#FFFFF0' },
    brand: { DEFAULT: '#D85A30' }
  }
}
```

---

## ═══════════════════════════════════
## NHÓM I: SEO & METADATA
## ═══════════════════════════════════

### [I1] Metadata tối ưu cho HSK 3.0
```typescript
// app/layout.tsx
export const metadata = {
  title: 'hanzi.io.vn — Học Tiếng Trung Chuẩn HSK 3.0',
  description: 'Nền tảng học tiếng Trung theo Tân HSK Giáo Trình 2026. Giáo trình chính thức HSK 3.0 của Hanban. 15-18 bài học mỗi cấp, 10 loại bài tập, AI hỗ trợ.',
  keywords: 'học tiếng Trung, HSK 3.0, Tân HSK giáo trình, học HSK online, thi HSK, tiếng Trung HSK 1 2 3',
  openGraph: {
    title: 'hanzi.io.vn — Học Tiếng Trung Chuẩn HSK 3.0',
    description: 'Giáo trình Tân HSK chính thức 2026. Học bài bản, thi đạt kết quả.',
    url: 'https://hanzi.io.vn',
    siteName: 'hanzi.io.vn',
    locale: 'vi_VN',
    type: 'website',
  }
}

// Mỗi trang bài học:
// title: "Bài 1: AI小语，你好！— HSK 1 | hanzi.io.vn"
// description: "Học bài 1 HSK 1: 9 từ vựng mới, 3 đoạn hội thoại, ngữ pháp cơ bản. Miễn phí."
```

---

## ═══════════════════════════════════
## THỨ TỰ THỰC HIỆN
## ═══════════════════════════════════

```
Bước 1: Chạy SQL schema (A1)
Bước 2: Import data (G1 → node scripts/import-all.js)
Bước 3: Navbar với HSK 3.0 badge (B2)
Bước 4: Trang chủ nhấn mạnh HSK 3.0 (B1)
Bước 5: Trang tổng quan giáo trình (C1)
Bước 6: Danh sách bài học (C2)
Bước 7: Nội dung bài học (C3)
Bước 8: Flashcard SRS (C4)
Bước 9: Quiz chọn nghĩa (C5)
Bước 10: Điền từ (C6)
Bước 11: Dashboard (E1)
Bước 12: Trang nâng cấp + SePay (E2)
Bước 13: Các mục phụ D1-D10
Bước 14: API routes (F1)
Bước 15: SEO metadata (I1)
Bước 16: Deploy Netlify (xem PROJECT_HANDOVER.md)
```

---
*V3 — Cập nhật dựa trên phân tích trực tiếp 3 giáo trình PDF New HSK Course 1, 2, 3 (2026)*
*Tổng hợp bởi Claude Sonnet 4.6*
